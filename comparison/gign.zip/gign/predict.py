import os
os.environ['CUDA_VISIBLE_DEVICES'] = "0"

import pandas as pd
import torch
import numpy as np

from GIGN import GIGN
from dataset_GIGN import GraphDataset, PLIDataLoader
from utils import load_model_dict

data_root = './data'
data_dir = os.path.join(data_root, 'toy_set')

graph_type = 'Graph_GIGN'
batch_size = 128

model_path = (
    './model/20221121_074758_GIGN_repeat0/model/'
    'epoch-532, train_loss-0.1162, train_rmse-0.3408, '
    'valid_rmse-1.1564, valid_pr-0.7813.pt'
)


data_df = pd.read_csv(
    os.path.join(data_root, 'toy_examples.csv')
)

if '-logKd/Ki' not in data_df.columns:
    data_df['-logKd/Ki'] = 0.0

test_set = GraphDataset(
    data_dir,
    data_df,
    graph_type=graph_type,
    create=False
)

test_loader = PLIDataLoader(
    test_set,
    batch_size=batch_size,
    shuffle=False,
    num_workers=0
)

device = torch.device(
    'cuda:0' if torch.cuda.is_available() else 'cpu'
)

model = GIGN(35, 256).to(device)

load_model_dict(model, model_path)
model.eval()

predictions = []

with torch.no_grad():

    for data in test_loader:

        data = data.to(device)

        pred = model(data)

        predictions.extend(
            pred.detach().cpu().numpy().reshape(-1)
        )


predictions = np.array(predictions, dtype=float)

results = pd.DataFrame({
    'pdbid': data_df['pdbid'],
    'Predicted_pKd_pKi': predictions,
    'Predicted_dG_kcal_mol': -1.364 * predictions
})

results.to_csv(
    'GIGN_toy_set_predictions.csv',
    index=False
)

print(results.to_string(index=False))
print('\nResults saved to GIGN_toy_set_predictions.csv')

